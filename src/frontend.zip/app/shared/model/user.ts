export interface User {
    id: number,
    strUserName: string,
    strPassword: string,
    strStatus: string,
    ingIdBasicData: number,
    ingIdDependence: number
}