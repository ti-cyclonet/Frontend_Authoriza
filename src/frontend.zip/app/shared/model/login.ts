export interface LoginDTO{
    applicationName: string;
    email: string;
    password: string;
}